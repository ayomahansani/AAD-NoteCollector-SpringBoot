package lk.ijse.notecollectorspringboot.dto;

import java.io.Serializable;

public interface NoteStatus extends Serializable,SuperDTO {
}
