package lk.ijse.notecollectorspringboot.dto;

import java.io.Serializable;

public interface UserStatus extends Serializable,SuperDTO {
}
