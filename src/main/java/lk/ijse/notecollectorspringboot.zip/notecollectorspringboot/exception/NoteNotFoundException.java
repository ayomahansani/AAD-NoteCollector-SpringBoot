package lk.ijse.notecollectorspringboot.exception;

public class NoteNotFoundException extends RuntimeException {
    public NoteNotFoundException() {
    }

    public NoteNotFoundException(String message) {

    }
    public NoteNotFoundException(String message, Throwable cause) {

    }

}
