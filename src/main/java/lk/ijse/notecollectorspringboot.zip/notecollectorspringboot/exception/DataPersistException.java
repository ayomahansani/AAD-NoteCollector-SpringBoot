package lk.ijse.notecollectorspringboot.exception;

public class DataPersistException extends RuntimeException {
    public DataPersistException() {
    }

    public DataPersistException(String message) {

    }
    public DataPersistException(String message, Throwable cause) {

    }
}
